package storemanagementsystem;
import java.io.*;

public class Clothes implements Serializable
{
    private String type;
    private String color;
    private Brand brand;
    private int price;
    
    // Creating the constructor
    public Clothes(String type, String color, Brand brand, int price) {
        this.type = type;
        this.color = color;
        this.brand = brand;
        this.price = price;
    }
    
    //Getter and Setter
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
    
}        
