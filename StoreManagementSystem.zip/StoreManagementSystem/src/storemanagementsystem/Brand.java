
package storemanagementsystem;

import java.io.*;


public class Brand implements Serializable   // to get serializable interface
{
    private String nameOfBrand;
    
    // Creating the constructor
    public Brand(String nameOfBrand) {
        this.nameOfBrand = nameOfBrand;
    }
    public boolean equals(Brand brand) //compare two object of this class to make sure that they are the same 
    {
        return (this.nameOfBrand.equals(brand.nameOfBrand));
        
    }        
    
    //Getter and Setter
    public String getNameOfBrand() {
        return nameOfBrand;
    }

    public void setNameOfBrand(String nameOfBrand) {
        this.nameOfBrand = nameOfBrand;
    }
    
}
