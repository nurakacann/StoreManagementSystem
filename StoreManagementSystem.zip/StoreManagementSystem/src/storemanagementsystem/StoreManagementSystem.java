
package storemanagementsystem;
//Nura Kaçan
public class StoreManagementSystem {

  
    public static void main(String[] args) {
       new Menu().setVisible(true); 
    }
    
}

